package pagamento;

public interface SistemaDePagamento {
    boolean processarPagamento(double valor);
}
